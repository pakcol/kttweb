<x-layouts.app title="PLN - Piutang">
<link rel="stylesheet" href="{{ asset('css/plnPiutang.css') }}">

<section class="pln-piutang-container">
    <div class="piutang-form">
        <div class="form-left">
            {{-- NAMA PIUTANG --}}
            <label>Nama Piutang</label>
            <input 
                list="nama_piutang_list"
                id="nama_piutang"
                name="nama_piutang"
                placeholder="Ketik atau pilih nama piutang..."
            >

            <datalist id="nama_piutang_list">
                <option value="ALL">
                @foreach($namaPiutangList as $nama)
                    <option value="{{ $nama }}">
                @endforeach
            </datalist>

            {{-- TOTAL PIUTANG --}}
            <label>Total Piutang</label>
            <input type="text" id="totalPiutang" readonly>

            {{-- NAMA --}}
            <label>Nama</label>
            <input type="text" id="nama" readonly>

            {{-- HARGA --}}
            <label>Harga</label>
            <input type="text" id="harga" readonly>

            {{-- PEMBAYARAN --}}
            <label>Pembayaran</label>
            <select id="pembayaran">
                <option value="BCA">BCA</option>
                <option value="BNI">BNI</option>
                <option value="MANDIRI">MANDIRI</option>
                <option value="BRI">BRI</option>
                <option value="LUNAS">LUNAS</option>
            </select>
        </div>

        <div class="form-right">
            <button id="updateBtn" onclick="updateData()">UPDATE</button>
        </div>
    </div>

    <div class="table-section">
    <table id="piutangTable">
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Nama Pelanggan</th>
                <th>ID Pelanggan</th>
                <th>Kategori PPOB</th>
                <th>Harga</th>
                <th>Jenis Bayar</th>
                <th>Bank</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($piutang as $row)
                <tr onclick="selectRow(this)"
                    data-id="{{ $row->id }}"
                    data-nama="{{ $row->nama }}"
                    data-id-pel="{{ $row->pembayaranOnline->id_pel ?? '' }}"
                    data-harga="{{ $row->harga_bayar }}"
                    data-jenis-bayar="{{ $row->jenisBayar->jenis ?? '' }}"
                    data-bank="{{ $row->bank->nama ?? '' }}"
                >
                    <td>{{ $row->tgl_issued?->format('d-m-Y') }}</td>
                    <td>{{ $row->nama }}</td>
                    <td>{{ $row->pembayaranOnline->id_pel ?? '-' }}</td>
                    <td>{{ $row->pembayaranOnline->jenisPpob->nama ?? '-' }}</td>
                    <td>{{ number_format($row->harga_bayar) }}</td>
                    <td>{{ strtoupper($row->jenisBayar->jenis ?? '-') }}</td>
                    <td>{{ $row->bank->nama ?? '-' }}</td>
                    <td><span class="hint">Klik baris</span></td>
                </tr>
            @empty
                <tr>
                    <td colspan="8" style="text-align:center;font-weight:600;">
                        DATA KOSONG
                    </td>
                </tr>
            @endforelse
        </tbody>
    </table>
</div>
</section>

<script>
let selectedRow = null;
let allPiutangData = @json($piutang);

/* ================= TOTAL PIUTANG ================= */
function calculateTotalPiutang(namaPiutang) {
    if (!namaPiutang) {
        document.getElementById('totalPiutang').value = '';
        return;
    }

    let total = 0;

    if (namaPiutang === 'ALL') {
        allPiutangData.forEach(item => {
            total += parseInt(item.harga_bayar) || 0;
        });
    } else {
        allPiutangData.forEach(item => {
            if (item.nama === namaPiutang) {
                total += parseInt(item.harga_bayar) || 0;
            }
        });
    }

    document.getElementById('totalPiutang').value =
        new Intl.NumberFormat('id-ID').format(total);
}

// Event listener untuk perubahan nama piutang
document.getElementById('nama_piutang').addEventListener('input', function () {
    calculateTotalPiutang(this.value);
});

// Event listener untuk perubahan nama piutang (change event)
document.getElementById('nama_piutang').addEventListener('change', function () {
    calculateTotalPiutang(this.value);
});


function selectRow(row) {
    document.querySelectorAll('.pln-table tbody tr')
        .forEach(r => r.classList.remove('selected'));

    row.classList.add('selected');
    selectedRow = row;

    document.getElementById('nama').value = row.dataset.nama;
    document.getElementById('harga').value =
        new Intl.NumberFormat('id-ID').format(row.dataset.harga);

    document.getElementById('pembayaran').value =
        row.dataset.jenisBayar;

    calculateTotalPiutang(
        document.getElementById('nama_piutang').value
    );
}

function updateData() {
    if (!selectedRow) {
        alert("Silakan pilih data dari tabel terlebih dahulu.");
        return;
    }

    const rowId = selectedRow.dataset.id;
    const namaPiutang = document.getElementById('namaPiutang').value;
    const nama = document.getElementById('nama').value;
    const harga = document.getElementById('harga').value;
    const pembayaran = document.getElementById('pembayaran').value;

    // Kirim update ke server
    fetch(`/plnPiutang/${rowId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
            'Accept': 'application/json'
        },
        body: JSON.stringify({
            nama_piutang: namaPiutang,
            harga_jual: harga.replace(/\./g, ''),
            bayar: pembayaran,
            username: nama
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success || data.message) {
            // Update tampilan tabel
            const cells = selectedRow.getElementsByTagName('td');
            cells[3].innerText = new Intl.NumberFormat('id-ID').format(parseInt(harga.replace(/\./g, '')));
            cells[5].innerText = pembayaran;
            cells[6].innerText = namaPiutang;
            cells[10].innerText = nama;
            
            // Update data di array
            const index = allPiutangData.findIndex(item => item.id == rowId);
            if (index !== -1) {
                allPiutangData[index].nama_piutang = namaPiutang;
                allPiutangData[index].harga_jual = parseInt(harga.replace(/\./g, ''));
                allPiutangData[index].bayar = pembayaran;
                allPiutangData[index].username = nama;
            }
            
            calculateTotalPiutang(namaPiutang);
            alert("Data berhasil diperbarui!");
        } else {
            alert("Gagal memperbarui data.");
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert("Terjadi kesalahan saat memperbarui data.");
    });
}
</script>

<style>
.alert-dummy {
    background: #fff3cd;
    color: #856404;
    border: 1px solid #ffeeba;
    padding: 10px 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    font-size: 15px;
}
.alert-dummy code {
    background: #f9f2f4;
    color: #c7254e;
    padding: 2px 5px;
    border-radius: 4px;
}
</style>

</x-layouts.app>
